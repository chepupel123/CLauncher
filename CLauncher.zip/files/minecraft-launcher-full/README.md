# Minecraft Launcher для Linux

Минималистичный лаунчер Minecraft на C++20 с GUI на Dear ImGui и OpenGL. Разработан для работы на слабом железе (Intel i5-2300, NVIDIA GTS 450).

## Особенности

- **Легковес**: ~3 МБ на диске, минимальное потребление памяти
- **Минимальные зависимости**: только GLFW3 + OpenGL
- **C++20**: современный код без exception-heavy конструкций
- **Dear ImGui**: простой и быстрый интерфейс
- **Совместимость**: OpenGL 3.0+ (поддержка Fermi-архитектуры и старше)

## Требования

### Системные зависимости (Linux Mint/Ubuntu/Debian)

```bash
sudo apt-get install libglfw3-dev libgl1-mesa-dev libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev
```

### Компилятор

```bash
gcc -v  # g++ 11+ обязателен для C++20
```

## Структура проекта

```
minecraft-launcher/
├── CMakeLists.txt          # Конфиг сборки
├── README.md               # Этот файл
└── src/
    ├── main.cpp            # Точка входа
    ├── launcher.hpp/.cpp   # Основной класс
    ├── version_scanner.hpp/.cpp  # Сканирование версий
    └── java_launcher.hpp/.cpp    # Запуск Java процесса
```

## Сборка

### Вариант 1: С vendored ImGui

```bash
# Скачиваем ImGui если его нет
mkdir -p extern/imgui
cd extern/imgui
# Копируем файлы ImGui сюда (или как submodule)
cd ../..

# Сборка
mkdir build && cd build
cmake ..
make -j4
./minecraft-launcher
```

### Вариант 2: Системный ImGui (если установлен)

```bash
mkdir build && cd build
cmake ..
make -j4
./minecraft-launcher
```

## Использование

1. **Nickname** — введите ник для оффлайн-режима
2. **Version** — выберите версию из `~/.minecraft/versions/`
3. **Memory** — сколько памяти выделить Java (по умолчанию 1024 МБ)
4. **Play** — запустить игру

Лаунчер закроется после запуска Java, игра продолжит работу независимо.

## Особенности кода

### Оптимизация

- `-O2 -march=native` для максимальной производительности
- `-fno-exceptions` для минимального оверхеда
- `vsync=1` чтобы избежать спинлока
- Статическая памяти для строк и массивов

### Поддержка старого железа

- OpenGL 3.0 core (GTS 450 поддерживает)
- GLSL 1.30
- Без SSE4.2, но с AVX (песочница для Sandy Bridge)

## Логирование

Лаунчер выводит в stdout:

```
Found 3 Minecraft versions
Launching: java -Xmx1024M -Xms512M ...
Game launched with PID 12345
```

Ошибки в stderr.

## Примечания

- Для реального Minecraft нужны также файлы конфигурации JSON в `~/.minecraft/versions/VERSION/`
- Параметр `--assetIndex` может потребоваться для некоторых версий
- Лаунчер не скачивает файлы, только запускает установленные версии

## Компиляция и запуск примера

```bash
cd build
cmake ..
make -j4
./minecraft-launcher
```

## Лицензия

MIT
