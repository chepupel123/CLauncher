# Инструкция по сборке Minecraft Launcher

## 1. Подготовка окружения

### Linux Mint 22.3 / Ubuntu / Debian

```bash
# Установка компилятора и зависимостей
sudo apt-get update
sudo apt-get install -y build-essential git cmake
sudo apt-get install -y libglfw3-dev libgl1-mesa-dev libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev

# Проверка версии g++
g++ --version  # должен быть 11 или выше
```

## 2. Скачивание и подготовка

### Опция A: Автоматическая подготовка

```bash
# Перейдите в папку проекта
cd ~/minecraft-launcher

# Запустите setup скрипт
chmod +x setup.sh
./setup.sh
```

### Опция B: Ручная подготовка

```bash
# Создаем структуру папок
mkdir -p extern
cd extern

# Клонируем ImGui
git clone --depth 1 https://github.com/ocornut/imgui.git

cd ..
```

## 3. Сборка

### Способ 1: CMake (рекомендуется)

```bash
# Создаем папку build
mkdir -p build
cd build

# Генерируем Makefile
cmake ..

# Собираем проект
make -j4

# Проверяем результат
./minecraft-launcher
```

### Способ 2: Makefile

```bash
# Из корня проекта
make

# Запуск
./minecraft-launcher
```

### Способ 3: Вручную (без CMake)

```bash
mkdir -p build

g++ -std=c++20 -O2 -march=native -fno-exceptions \
    -I./src -I./extern/imgui -I./extern/imgui/backends \
    src/main.cpp \
    src/launcher.cpp \
    src/version_scanner.cpp \
    src/java_launcher.cpp \
    extern/imgui/imgui.cpp \
    extern/imgui/imgui_draw.cpp \
    extern/imgui/imgui_tables.cpp \
    extern/imgui/imgui_widgets.cpp \
    extern/imgui/backends/imgui_impl_glfw.cpp \
    extern/imgui/backends/imgui_impl_opengl3.cpp \
    -lglfw -lGL -lX11 -lXrandr -lXinerama -lXcursor \
    -o build/minecraft-launcher

strip build/minecraft-launcher
```

## 4. Использование

```bash
# Из папки build
./minecraft-launcher

# Или из корня (если через make)
./minecraft-launcher
```

## 5. Решение проблем

### Ошибка: `GLFW/glfw3.h: No such file`

```bash
sudo apt-get install libglfw3-dev
```

### Ошибка: `GL/gl.h: No such file`

```bash
sudo apt-get install libgl1-mesa-dev
```

### Ошибка: `X11 headers not found`

```bash
sudo apt-get install libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev
```

### Ошибка: `extern/imgui` не найден

```bash
# Скачиваем ImGui вручную
mkdir -p extern
git clone https://github.com/ocornut/imgui.git extern/imgui
```

### Компилятор слишком старый

```bash
# Проверьте версию
g++ --version

# Если старше 11, обновите
sudo apt-get install gcc-11 g++-11
export CXX=g++-11
```

## 6. Оптимизация для старого железа

Если у вас Intel i5-2300 или старше:

```bash
# Используйте флаг для Sandy Bridge
CXXFLAGS="-std=c++20 -O2 -march=sandybridge -fno-exceptions" make
```

### Поддерживаемые архитектуры:

- **Sandy Bridge** (i5-2xxx): `-march=sandybridge`
- **Ivy Bridge** (i5-3xxx): `-march=ivybridge`
- **Haswell** (i5-4xxx): `-march=haswell`
- **Broadwell** (i5-5xxx): `-march=broadwell`

## 7. Проверка размера бинарника

```bash
ls -lh build/minecraft-launcher  # должен быть ~2-3 МБ

# Если больше 5 МБ — пересоберите с флагом strip:
strip build/minecraft-launcher
```

## 8. Запуск Minecraft

Убедитесь что Java установлена:

```bash
java -version  # должна быть 8 или выше
```

Структура `~/.minecraft` должна быть:

```
~/.minecraft/
├── versions/
│   ├── 1.20/
│   │   ├── 1.20.jar
│   │   ├── 1.20.json
│   │   └── libraries/
│   └── 1.19/
│       └── ...
├── assets/
└── ...
```

## Готово!

Лаунчер готов к использованию. Все остальное — как обычно работать с Minecraft.
