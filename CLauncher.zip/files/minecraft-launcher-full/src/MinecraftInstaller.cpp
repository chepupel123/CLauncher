#include "MinecraftInstaller.h"
#include "version_manager.h"

#include <curl/curl.h>
#include <nlohmann/json.hpp>

#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <cstdlib>   // для std::system

namespace fs = std::filesystem;
using json = nlohmann::json;

namespace
{
    size_t write_file(void* ptr, size_t size, size_t count, FILE* file)
    {
        return fwrite(ptr, size, count, file);
    }

    bool download(const std::string& url, const fs::path& path)
    {
        CURL* curl = curl_easy_init();

        if (!curl)
            return false;

        fs::create_directories(path.parent_path());

        FILE* file = fopen(path.c_str(), "wb");

        if (!file)
        {
            curl_easy_cleanup(curl);
            return false;
        }

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_file);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
        curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);

        CURLcode result = curl_easy_perform(curl);

        fclose(file);
        curl_easy_cleanup(curl);

        if (result != CURLE_OK)
        {
            fs::remove(path);
            std::cerr << "Download failed: " << url << '\n';
            return false;
        }

        return true;
    }

    static size_t write_string_callback(void* ptr, size_t size, size_t nmemb, void* userdata) {
        std::string* str = static_cast<std::string*>(userdata);
        str->append(static_cast<char*>(ptr), size * nmemb);
        return size * nmemb;
    }

    static json download_json(const std::string& url)
    {
        CURL* curl = curl_easy_init();
        if (!curl)
            throw std::runtime_error("Failed to initialize curl");

        std::string data;

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "Minecraft-Launcher/1.0");
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_string_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &data);

        CURLcode result = curl_easy_perform(curl);

        long http_code = 0;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
        curl_easy_cleanup(curl);

        if (result != CURLE_OK) {
            throw std::runtime_error(
                std::string("Failed to download JSON: ") +
                curl_easy_strerror(result) +
                " (HTTP code: " + std::to_string(http_code) + ")"
            );
        }

        if (data.empty())
            throw std::runtime_error("Downloaded JSON is empty");

        return json::parse(data);
    }
}

bool MinecraftInstaller::install(
    const std::string& version)
{
    try
    {
        const char* home = std::getenv("HOME");

        if (!home)
        {
            std::cerr << "HOME environment variable is not set\n";
            return false;
        }

        fs::path minecraft =
            fs::path(home) / ".minecraft";

        fs::path version_dir =
            minecraft / "versions" / version;

        fs::path version_json =
            version_dir / (version + ".json");

        fs::path client_jar =
            version_dir / (version + ".jar");

        /*
         * Уже установлена?
         */
        if (fs::exists(version_json) &&
            fs::exists(client_jar))
        {
            std::cout
                << "Minecraft " << version
                << " is already installed\n";

            return true;
        }

        /*
         * Ищем версию в уже загруженном
         * Mojang manifest.
         */
        auto versions =
            VersionManager::parse_manifest();

        std::string version_url;

        for (const auto& item : versions)
        {
            if (item.id == version)
            {
                version_url = item.url;
                break;
            }
        }

        if (version_url.empty())
        {
            std::cerr
                << "Version not found in manifest: "
                << version << '\n';

            return false;
        }

        std::cout
            << "Downloading Minecraft "
            << version << " metadata...\n";

        fs::create_directories(version_dir);

        /*
         * Скачиваем version.json
         */
        json metadata =
            download_json(version_url);

        {
            std::ofstream file(version_json);

            if (!file)
            {
                std::cerr
                    << "Failed to write "
                    << version_json << '\n';

                return false;
            }

            file << metadata.dump(2);
        }

        /*
         * Minecraft client.jar
         */
        if (!metadata.contains("downloads") ||
            !metadata["downloads"].contains("client"))
        {
            std::cerr
                << "Client download information "
                   "is missing\n";

            return false;
        }

        std::string client_url =
            metadata["downloads"]["client"]["url"];

        std::cout
            << "Downloading Minecraft client...\n";

        if (!download(client_url, client_jar))
            return false;

        /*
         * Libraries
         *
         * Храним их внутри версии, потому что
         * существующий JavaLauncher ищет их
         * именно здесь.
         */
        fs::path libraries =
            version_dir / "libraries";

        for (const auto& library :
             metadata["libraries"])
        {
            if (!library.contains("downloads"))
                continue;

            if (!library["downloads"].contains("artifact"))
                continue;

            auto artifact =
                library["downloads"]["artifact"];

            std::string url =
                artifact["url"];

            std::string relative =
                artifact["path"];

            fs::path destination =
                libraries / relative;

            if (fs::exists(destination))
                continue;

            std::cout
                << "Downloading library: "
                << relative << '\n';

            if (!download(url, destination))
                return false;
        }

        /*
         * Assets
         */
        if (metadata.contains("assetIndex"))
        {
            std::string asset_index_url =
                metadata["assetIndex"]["url"];

            std::string asset_index_id =
                metadata["assetIndex"]["id"];

            fs::path assets =
                minecraft / "assets";

            fs::path indexes =
                assets / "indexes";

            fs::path index_file =
                indexes /
                (asset_index_id + ".json");

            if (!fs::exists(index_file))
            {
                std::cout
                    << "Downloading asset index...\n";

                if (!download(
                        asset_index_url,
                        index_file))
                {
                    return false;
                }
            }

            std::ifstream file(index_file);

            if (!file)
            {
                std::cerr
                    << "Failed to open asset index\n";

                return false;
            }

            json asset_index =
                json::parse(file);

            if (asset_index.contains("objects"))
            {
                for (const auto& [name, object] :
                     asset_index["objects"].items())
                {
                    std::string hash =
                        object["hash"];

                    std::string prefix =
                        hash.substr(0, 2);

                    fs::path object_file =
                        assets /
                        "objects" /
                        prefix /
                        hash;

                    if (fs::exists(object_file))
                        continue;

                    std::string url =
                        "https://resources.download.minecraft.net/" +
                        prefix + "/" + hash;

                    std::cout
                        << "Downloading asset: "
                        << name << '\n';

                    if (!download(
                            url,
                            object_file))
                    {
                        return false;
                    }
                }
            }
        }

        // ========== ДОБАВЛЕНО: скачивание и распаковка Linux natives ==========
        {
            fs::path natives_dir = version_dir / "natives";
            fs::create_directories(natives_dir);

            for (const auto& library : metadata["libraries"])
            {
                if (!library.contains("downloads")) continue;
                auto& downloads = library["downloads"];
                if (!downloads.contains("classifiers")) continue;
                auto& classifiers = downloads["classifiers"];
                if (!classifiers.contains("natives-linux")) continue;

                auto native_info = classifiers["natives-linux"];
                std::string url = native_info["url"];
                std::string path = native_info["path"];

                fs::path dest_jar = libraries / path;
                if (fs::exists(dest_jar)) continue;

                std::cout << "Downloading natives: " << path << "\n";
                if (!download(url, dest_jar)) return false;

                // Распаковываем .jar (на самом деле это zip с .so)
                std::string unzip_cmd = "unzip -q " + dest_jar.string() + " -d " + natives_dir.string();
                if (std::system(unzip_cmd.c_str()) != 0) {
                    std::cerr << "Failed to extract natives\n";
                    return false;
                }
            }
        }
        // =====================================================================

        std::cout
            << "Minecraft " << version
            << " installed successfully\n";

        return true;
    }
    catch (const std::exception& e)
    {
        std::cerr
            << "MinecraftInstaller error: "
            << e.what() << '\n';

        return false;
    }
}
