#include "java_launcher.h"
#include "JavaManager.h"
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

bool JavaLauncher::launch(const std::string& nickname, 
                          const std::string& version, 
                          int memory_mb) {
    
    const char* home = std::getenv("HOME");
    if (!home) {
        std::cerr << "ERROR: HOME не установлена\n";
        return false;
    }

    std::string minecraft_dir = std::string(home) + "/.minecraft";
    std::string versions_dir = minecraft_dir + "/versions";
    std::string version_dir = versions_dir + "/" + version;
    std::string jar_path = version_dir + "/" + version + ".jar";

    if (!fs::exists(jar_path)) {
        std::cerr << "ERROR: JAR файл не найден: " << jar_path << "\n";
        return false;
    }

    std::cout << "✓ JAR найден: " << jar_path << "\n";

    // --- Получаем правильную Java через JavaManager ---
    JavaManager javaManager;
    std::string java_path;
    try {
        java_path = javaManager.ensureJava(version).string();
    } catch (const std::exception& e) {
        std::cerr << "ERROR: Не удалось получить Java: " << e.what() << "\n";
        return false;
    }
    std::cout << "✓ Java: " << java_path << "\n";

    // --- Определяем пути к библиотекам Java для LD_LIBRARY_PATH ---
    fs::path java_bin_path = fs::path(java_path);
    fs::path java_root = java_bin_path.parent_path().parent_path(); // .../runtime/java17
    std::string lib_path = (java_root / "lib").string();
    std::string libjli_path = (java_root / "lib" / "jli").string();
    std::string libserver_path = (java_root / "lib" / "server").string();

    std::string ld_library_path = lib_path + ":" + libjli_path + ":" + libserver_path;
    const char* existing = std::getenv("LD_LIBRARY_PATH");
    if (existing && existing[0] != '\0') {
        ld_library_path += ":" + std::string(existing);
    }

    // --- Строим classpath ---
    std::string classpath = jar_path;
    std::string libs_dir = version_dir + "/libraries";
    if (fs::exists(libs_dir)) {
        try {
            for (const auto& entry : fs::recursive_directory_iterator(libs_dir)) {
                if (entry.path().extension() == ".jar") {
                    classpath += ":" + entry.path().string();
                }
            }
        } catch (...) {
            std::cerr << "WARNING: Не удалось сканировать libraries\n";
        }
    }

    // --- Путь к natives ---
    std::string natives_dir = version_dir + "/natives";
    if (!fs::exists(natives_dir)) {
        fs::create_directories(natives_dir);
    }

    // --- Формируем команду с установкой LD_LIBRARY_PATH ---
    std::ostringstream cmd;
cmd << java_path
    << " -Xmx" << memory_mb << "M"
    << " -Xms" << (memory_mb / 2) << "M"
    << " -Djava.library.path=\"" << natives_dir << "\""
    << " -cp \"" << classpath << "\""
    << " net.minecraft.client.main.Main"
    << " --username \"" << nickname << "\""
    << " --accessToken \"null\""   // Добавлено
    << " --version " << version
    << " --gameDir \"" << minecraft_dir << "\"";

    std::string command = cmd.str();

    std::cout << "\n";
    std::cout << "═══════════════════════════════════════════\n";
    std::cout << "🎮 ЗАПУСК MINECRAFT\n";
    std::cout << "═══════════════════════════════════════════\n";
    std::cout << "Ник:       " << nickname << "\n";
    std::cout << "Версия:    " << version << "\n";
    std::cout << "Память:    " << memory_mb << " МБ\n";
    std::cout << "Java:      " << java_path << "\n";
    std::cout << "═══════════════════════════════════════════\n\n";

    std::cout << "Выполняем: " << command << "\n\n";

    int ret = system(command.c_str());
    
    if (ret == 0) {
        std::cout << "✓ Игра запущена успешно!\n";
        return true;
    } else {
        std::cerr << "ERROR: Ошибка запуска (код " << ret << ")\n";
        return false;
    }
}

void JavaLauncher::open_url(const std::string& url) {
    std::string cmd = "xdg-open \"" + url + "\" 2>/dev/null &";
    std::cout << "Открываем: " << url << "\n";
    
    if (system(cmd.c_str()) == 0) {
        std::cout << "✓ URL открыт\n";
    }
}
