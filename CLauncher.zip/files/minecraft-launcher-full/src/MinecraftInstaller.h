#pragma once

#include <string>

namespace MinecraftInstaller
{
    bool install(const std::string& version);
}
