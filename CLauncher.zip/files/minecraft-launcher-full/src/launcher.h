#pragma once
#include <string>
#include <vector>
#include <memory>

class Launcher {
public:
    struct Config {
        std::string nickname = "Steve";
        std::string selected_version;
        int memory_mb = 1024;
        std::string discord_url = "https://discord.gg/aQ7htke3mU";
    };

    Launcher();
    ~Launcher();

    void init();
    void render();
    bool should_close() const;

    Config& get_config() { return config_; }
    const std::vector<std::string>& get_versions() const { return release_versions_; }

private:
    Config config_;
    std::vector<std::string> release_versions_;  // НОВОЕ: версии с кешированием
    int memory_index_ = 1;                         // НОВОЕ: индекс памяти (0-4)
    bool should_close_ = false;
    
    // OpenGL/GLFW
    struct GLFWwindow* window_ = nullptr;
    unsigned int clear_color_ = 0x1e1e2e; // solarized dark

    void setup_imgui();
    void draw_ui();
    void handle_play_button();
};
