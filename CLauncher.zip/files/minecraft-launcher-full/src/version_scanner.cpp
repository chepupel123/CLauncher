#include "version_scanner.h"
#include <filesystem>
#include <iostream>
#include <algorithm>

namespace fs = std::filesystem;

std::string VersionScanner::get_versions_path() {
    const char* home = std::getenv("HOME");
    if (!home) home = ".";
    return std::string(home) + "/.minecraft/versions";
}

std::vector<std::string> VersionScanner::scan_versions() {
    std::vector<std::string> versions;
    auto versions_dir = get_versions_path();

    try {
        if (!fs::exists(versions_dir)) {
            std::cerr << "Versions dir not found: " << versions_dir << "\n";
            return versions;
        }

        for (const auto& entry : fs::directory_iterator(versions_dir)) {
            if (entry.is_directory()) {
                auto version_name = entry.path().filename().string();
                // Проверяем наличие jar файла
                auto jar_path = entry.path() / (version_name + ".jar");
                if (fs::exists(jar_path)) {
                    versions.push_back(version_name);
                }
            }
        }

        // Сортируем версии по имени (новые последние)
        std::sort(versions.begin(), versions.end());
        std::reverse(versions.begin(), versions.end());

        std::cout << "Found " << versions.size() << " Minecraft versions\n";

    } catch (const std::exception& e) {
        std::cerr << "Version scan error: " << e.what() << "\n";
    }

    return versions;
}
