#include "launcher.h"
#include "version_manager.h"
#include "java_launcher.h"
#include "MinecraftInstaller.h"   // <-- ДОБАВЛЕНО
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <GLFW/glfw3.h>
#include <GL/gl.h>
#include <iostream>

// ===== ДИСКРЕТНЫЕ ЗНАЧЕНИЯ ПАМЯТИ =====
static const int RAM_OPTIONS[] = {512, 1024, 2048, 3072, 4096};
static const int RAM_OPTIONS_COUNT = 5;

Launcher::Launcher() {
    glfwSetErrorCallback([](int err, const char* desc) {
        std::cerr << "GLFW Error " << err << ": " << desc << "\n";
    });

    if (!glfwInit()) {
        throw std::runtime_error("GLFW init failed");
    }
}

Launcher::~Launcher() {
    if (window_) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplGlfw_Shutdown();
        ImGui::DestroyContext();
        glfwDestroyWindow(window_);
    }
    glfwTerminate();
}

void Launcher::init() {
    // OpenGL 3.0+ (для GTS 450 достаточно GLSL 130)
    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

    window_ = glfwCreateWindow(700, 550, "Minecraft Launcher", nullptr, nullptr);
    if (!window_) throw std::runtime_error("GLFW window creation failed");

    glfwMakeContextCurrent(window_);
    glfwSwapInterval(1); // vsync

    setup_imgui();
    
    // === НОВОЕ: Инициализация версий с кешированием ===
    std::cout << "Initializing version manager...\n";
    
    // Пытаемся скачать свежий манифест
    if (!VersionManager::fetch_and_cache_manifest()) {
        std::cout << "Using cached manifest\n";
    }
    
    // Парсим локальный манифест
    release_versions_ = VersionManager::get_release_versions();
    
    if (!release_versions_.empty()) {
        config_.selected_version = release_versions_[0];
    } else {
        std::cerr << "WARNING: No release versions found!\n";
    }
    
    std::cout << "Version manager initialized\n";
    // ================================================
    
    // Инициализируем индекс памяти (по умолчанию 1024 MB = индекс 1)
    memory_index_ = 1;
    config_.memory_mb = RAM_OPTIONS[memory_index_];
}

void Launcher::setup_imgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    // Минималистичный стиль
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowPadding = ImVec2(12, 12);
    style.FramePadding = ImVec2(8, 6);
    style.ItemSpacing = ImVec2(8, 8);
    style.WindowRounding = 0.0f;
    style.FrameRounding = 0.0f;

    ImGui_ImplGlfw_InitForOpenGL(window_, true);
    ImGui_ImplOpenGL3_Init("#version 130");
    ImGui::GetIO().Fonts->AddFontDefault();
}

void Launcher::render() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    draw_ui();

    ImGui::Render();
    int display_w, display_h;
    glfwGetFramebufferSize(window_, &display_w, &display_h);
    glViewport(0, 0, display_w, display_h);
    glClearColor(
        ((clear_color_ >> 0) & 0xFF) / 255.f,
        ((clear_color_ >> 8) & 0xFF) / 255.f,
        ((clear_color_ >> 16) & 0xFF) / 255.f,
        1.f
    );
    glClear(GL_COLOR_BUFFER_BIT);

    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    glfwSwapBuffers(window_);
    glfwPollEvents();

    if (glfwWindowShouldClose(window_)) should_close_ = true;
}

void Launcher::draw_ui() {
    ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_FirstUseEver);
    
    ImGui::Begin("##launcher_main", nullptr, 
        ImGuiWindowFlags_NoMove | 
        ImGuiWindowFlags_NoResize | 
        ImGuiWindowFlags_NoTitleBar);

    ImGui::Text("Minecraft Launcher");
    ImGui::Separator();

    // Nickname input
    static char nickname_buf[32] = "Steve";
    ImGui::InputText("##nickname", nickname_buf, sizeof(nickname_buf), 
                     ImGuiInputTextFlags_CharsNoBlank);
    ImGui::SameLine();
    ImGui::Text("Nickname");

    // Version selector
    if (ImGui::BeginCombo("##version_combo", config_.selected_version.c_str())) {
        for (const auto& ver : release_versions_) {
            bool is_selected = (ver == config_.selected_version);
            if (ImGui::Selectable(ver.c_str(), is_selected)) {
                config_.selected_version = ver;
            }
            if (is_selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::SameLine();
    ImGui::Text("Version");

    ImGui::Spacing();
    
    // === НОВОЕ: Дискретный слайдер для памяти ===
    ImGui::Text("Memory allocation:");
    ImGui::RadioButton("512 MB##ram", &memory_index_, 0); ImGui::SameLine();
    ImGui::RadioButton("1024 MB##ram", &memory_index_, 1); ImGui::SameLine();
    ImGui::RadioButton("2048 MB##ram", &memory_index_, 2); ImGui::SameLine();
    ImGui::RadioButton("3072 MB##ram", &memory_index_, 3); ImGui::SameLine();
    ImGui::RadioButton("4096 MB##ram", &memory_index_, 4);
    
    // Обновляем значение памяти на основе индекса
    config_.memory_mb = RAM_OPTIONS[memory_index_];
    
    ImGui::Text("Selected: %d MB", config_.memory_mb);
    // ========================================

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // Play button
    if (ImGui::Button("Play", ImVec2(-1, 40))) {
        config_.nickname = nickname_buf;
        handle_play_button();
    }

    ImGui::Spacing();
    ImGui::Separator();
    
    // Discord link
    if (ImGui::Button("Report bug on Discord", ImVec2(-1, 0))) {
        JavaLauncher::open_url(config_.discord_url);
    }

    ImGui::End();
}

void Launcher::handle_play_button() {
    if (config_.selected_version.empty()) {
        std::cerr << "Error: No version selected\n";
        return;
    }

    if (config_.nickname.empty()) {
        config_.nickname = "Steve";
    }

    // ===== ДОБАВЛЕНО: установка игры, если отсутствует =====
    if (!MinecraftInstaller::install(config_.selected_version)) {
        std::cerr << "Failed to install Minecraft " << config_.selected_version << "\n";
        return;
    }

    std::cout << "Launching with: nickname=" << config_.nickname 
              << ", version=" << config_.selected_version 
              << ", memory=" << config_.memory_mb << "MB\n";

    bool launched = JavaLauncher::launch(
        config_.nickname,
        config_.selected_version,
        config_.memory_mb
    );

    if (launched) {
        should_close_ = true;
    } else {
        std::cerr << "Failed to launch game\n";
    }
}

bool Launcher::should_close() const {
    return should_close_;
}
