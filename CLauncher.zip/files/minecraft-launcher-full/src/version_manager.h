#pragma once
#include <string>
#include <vector>
#include <optional>

namespace VersionManager {
    struct Version {
        std::string id;
        std::string type;        // "release", "snapshot", "old_alpha", "old_beta"
        std::string url;
        std::string sha1;
        std::string time;
        std::string releaseTime;
    };

    // Скачивает манифест с mojang.com, кеширует локально
    // При ошибке сети использует локальный кеш
    bool fetch_and_cache_manifest();

    // Парсит локальный манифест и возвращает версии
    std::vector<Version> parse_manifest();

    // Фильтрует только релизы (type == "release")
    std::vector<std::string> get_release_versions();

    // Получает полный путь к файлу кеша
    std::string get_manifest_cache_path();

    // Проверяет наличие локального кеша
    bool has_manifest_cache();

    // Возвращает время последнего обновления кеша (timestamp)
    long get_cache_timestamp();
}
