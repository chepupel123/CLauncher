#pragma once
#include <vector>
#include <string>

namespace VersionScanner {
    std::vector<std::string> scan_versions();
    std::string get_versions_path();
}
