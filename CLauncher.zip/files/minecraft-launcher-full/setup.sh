#!/bin/bash
set -e

echo "=== Minecraft Launcher Setup ==="

# Проверяем зависимости
echo "Checking dependencies..."

if ! command -v g++ &> /dev/null; then
    echo "ERROR: g++ not found. Install: sudo apt-get install build-essential"
    exit 1
fi

if ! pkg-config --exists glfw3; then
    echo "ERROR: GLFW3 not found. Install: sudo apt-get install libglfw3-dev"
    exit 1
fi

if ! pkg-config --exists gl; then
    echo "ERROR: OpenGL not found. Install: sudo apt-get install libgl1-mesa-dev"
    exit 1
fi

# Скачиваем ImGui если его нет
if [ ! -d "extern/imgui" ]; then
    echo "Downloading Dear ImGui..."
    mkdir -p extern
    cd extern
    
    # Скачиваем последнюю версию ImGui
    git clone --depth 1 https://github.com/ocornut/imgui.git imgui || \
    wget -q -O imgui.zip https://github.com/ocornut/imgui/archive/refs/heads/master.zip && \
    unzip -q imgui.zip && \
    mv imgui-master imgui
    
    cd ..
fi

echo "✓ Dependencies OK"
echo "✓ ImGui OK"

# Создаем папку build
mkdir -p build

echo ""
echo "=== Setup Complete ==="
echo ""
echo "To build:"
echo "  cd build && cmake .. && make -j4"
echo ""
echo "Or use Makefile:"
echo "  make"
echo ""
