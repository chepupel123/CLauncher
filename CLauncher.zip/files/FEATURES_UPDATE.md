# Обновление с дискретным RAM слайдером и кешированием версий

## 1️⃣ Дискретный ползунок памяти (512/1024/2048/3072/4096 MB)

### Что было:
```cpp
ImGui::SliderInt("##memory", &config_.memory_mb, 256, 4096);
// → плавный слайдер, может быть любое значение
```

### Что стало:
```cpp
// Фиксированные значения в массиве
static const int RAM_OPTIONS[] = {512, 1024, 2048, 3072, 4096};

// RadioButton для выбора по индексу (0-4)
ImGui::RadioButton("512 MB##ram", &memory_index_, 0);
ImGui::RadioButton("1024 MB##ram", &memory_index_, 1);
// ...

// Обновляем значение
config_.memory_mb = RAM_OPTIONS[memory_index_];
```

### Преимущества:
✅ Четкий выбор без "странных" значений  
✅ Меньше ошибок конфигурации  
✅ Компактно в UI  

---

## 2️⃣ Кеширование версий Minecraft (оффлайн режим)

### Архитектура:

```
При запуске лаунчера:
    ↓
├─ Попытка скачать манифест (curl)
│   ├─ Успех → кешируем в ~/.minecraft-launcher/versions_manifest.json
│   └─ Ошибка → используем локальный кеш
│
└─ Парсим локальный JSON
    ├─ Фильтруем type == "release"
    └─ Заполняем vector<string> release_versions
```

### Структура манифеста Mojang:

```json
{
  "versions": [
    {
      "id": "1.20.1",
      "type": "release",           ← только это нам нужно
      "url": "https://...",
      "sha1": "abc123",
      "time": "2023-12-14T...",
      "releaseTime": "2023-12-14T..."
    },
    {
      "id": "24w03a",
      "type": "snapshot",           ← пропускаем эти
      "url": "https://...",
      ...
    }
  ]
}
```

### Поток данных:

```cpp
// 1. Инициализация
bool VersionManager::fetch_and_cache_manifest() {
    // Curl запрос к https://piston-meta.mojang.com/mc/game/version_manifest_v2.json
    // Сохраняем в ~/.minecraft-launcher/versions_manifest.json
    // При ошибке → молча используем локальный кеш
}

// 2. Парсинг
std::vector<Version> VersionManager::parse_manifest() {
    // Читаем локальный JSON
    // Парсим через nlohmann/json
    // Возвращаем все версии (разные типы)
}

// 3. Фильтрация
std::vector<std::string> VersionManager::get_release_versions() {
    // Берем все версии
    // Оставляем только where type == "release"
    // Возвращаем vector<string> с ID (1.20, 1.19.3, и т.д.)
}
```

---

## 🔧 Установка зависимостей

### libcurl (уже должен быть):
```bash
sudo apt-get install libcurl4-openssl-dev
```

### nlohmann/json (новое)

#### Способ 1: Через пакетный менеджер (рекомендуется)
```bash
sudo apt-get install nlohmann-json3-dev
```

#### Способ 2: Vendored заголовок (если способ 1 не сработал)
```bash
# Скачиваем файл json.hpp
mkdir -p include/nlohmann
cd include/nlohmann
wget https://github.com/nlohmann/json/releases/download/v3.11.2/json.hpp
# Или используем curl:
# curl -L -o json.hpp https://github.com/nlohmann/json/releases/download/v3.11.2/json.hpp

cd ../..
# Добавляем в CMakeLists.txt:
target_include_directories(minecraft-launcher PRIVATE include/)
```

---

## 📝 Замена файлов в проекте

### Шаг 1: Установите nlohmann/json

```bash
sudo apt-get install nlohmann-json3-dev
# или способ 2 выше
```

### Шаг 2: Замените файлы

```bash
cd ~/Рабочий\ стол/files/minecraft-launcher-full/

# Заголовки
cp launcher_with_discrete_slider.hpp src/launcher.hpp
cp version_manager.hpp src/
cp version_manager.cpp src/

# Реализация
cp launcher_with_discrete_slider.cpp src/launcher.cpp

# Конфигурация
cp CMakeLists_with_json.txt CMakeLists.txt
```

### Шаг 3: Пересоберите

```bash
cd build
cmake ..
make clean
make -j4
./minecraft-launcher
```

---

## 📊 Файлы кеша

### Расположение:
```
~/.minecraft-launcher/
└── versions_manifest.json  (скачивается с сервера, кешируется локально)
```

### Размер:
- ~700 КБ (примерно)

### Время жизни:
- Неограниченно, пока не будет пересоздан
- При каждом запуске лаунчера пытается обновиться
- Если интернет недоступен — использует старый кеш

---

## 🧪 Тестирование

### Тест 1: С интернетом

```bash
./minecraft-launcher
# В консоли должно быть:
# "Manifest cached to ~/.minecraft-launcher/versions_manifest.json"
# "Parsed 800+ versions from manifest"
# "Found 100+ release versions"
```

### Тест 2: Без интернета

```bash
# Отключите интернет или используйте этот трюк:
# Отредактируйте версию_manager.cpp, измените URL на невалидный:
// const char* manifest_url = "http://invalid.local/manifest.json";

./minecraft-launcher
# В консоли должно быть:
# "Curl error: ..."
# "No internet connection. Using cached manifest if available."
# "Parsed 800+ versions from manifest"
```

### Тест 3: Слайдер памяти

```
UI должна показывать:
☐ 512 MB
☑ 1024 MB  (по умолчанию)
☐ 2048 MB
☐ 3072 MB
☐ 4096 MB

Selected: 1024 MB
```

При клике на другой радио-кнопон → обновляется текст "Selected: X MB"

---

## 🎯 Преимущества обновления

### До:
❌ Версии считывались только из локальной папки  
❌ Слайдер памяти мог быть 777 MB или 1337 MB  
❌ Нужно вручную обновлять список версий  

### После:
✅ Версии автоматически скачиваются с сервера Mojang  
✅ Кешируются локально для оффлайн режима  
✅ Только фиксированные значения памяти  
✅ UI показывает все официальные версии (2023 год)  

---

## 📋 Логирование

При запуске лаунчер выводит:

```
Initializing version manager...
Manifest cached to ~/.minecraft-launcher/versions_manifest.json
Parsed 850 versions from manifest
Found 127 release versions (filtered from 850 total)
Version manager initialized
```

Или при ошибке сети:

```
Initializing version manager...
Curl error: Could not resolve host name
No internet connection. Using cached manifest if available.
Parsed 850 versions from manifest
Found 127 release versions (filtered from 850 total)
Version manager initialized
```

---

## 🔄 Обновление кеша

Кеш обновляется автоматически при каждом запуске лаунчера:

```cpp
// В launcher.cpp init()
if (!VersionManager::fetch_and_cache_manifest()) {
    // ошибка сети, используем старый кеш
    std::cout << "Using cached manifest\n";
}
```

Если нужно принудительно очистить кеш:

```bash
rm ~/.minecraft-launcher/versions_manifest.json
# При следующем запуске будет загружен заново
```

---

## 💾 Структура кода

```
version_manager.hpp/cpp
├── fetch_and_cache_manifest()     ← curl + JSON парсинг
├── parse_manifest()                ← читает локальный JSON
├── get_release_versions()          ← фильтрация type=="release"
├── get_manifest_cache_path()       ← путь к кешу
├── has_manifest_cache()            ← проверка наличия
└── get_cache_timestamp()           ← время последнего обновления

launcher.hpp/cpp
├── release_versions_          ← vector всех релизов
├── memory_index_              ← текущий выбранный индекс RAM (0-4)
└── draw_ui()                  ← радио-кнопки вместо слайдера
```

---

## 🚀 Готово!

После обновления у вас будет:
- ✅ Дискретный выбор памяти (512/1024/2048/3072/4096 MB)
- ✅ Автоматическое скачивание версий с Mojang
- ✅ Кеширование для работы без интернета
- ✅ Фильтрация только релизов (без snapshot)
- ✅ Красивая UI с информацией о выборе

Компилируйте и запускайте! 🎮
